
CREATE DATABASE order_processing_db;
